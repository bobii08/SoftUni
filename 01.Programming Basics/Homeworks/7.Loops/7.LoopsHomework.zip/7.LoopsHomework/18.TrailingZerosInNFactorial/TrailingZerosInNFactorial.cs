﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Numerics;

namespace _18.TrailingZerosInNFactorial
{
    class TrailingZerosInNFactorial
    {
        private static void Main()
        {
            int n = int.Parse(Console.ReadLine());
            
            int zerosToBeMultipliedBy2 = 0;
            int singleZero = 0;
            if (n < 5)
            {
                Console.WriteLine(0);
                return;
            }
            else if (n < 10)
            {
                Console.WriteLine(1);
                return;
            }
            else
            {
                zerosToBeMultipliedBy2 = n / 10;
                if (n % 10 > 4 && n % 10 <= 9)
                {
                    singleZero++;
                }
            }

            // does not work correctly with bigger numbers
            Console.WriteLine((zerosToBeMultipliedBy2 * 2) + singleZero);
        }
    }
}
