﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _14.CurrentDateAndTime
{
    class CurrentDateAndTime
    {
        static void Main()
        {
            Console.WriteLine("The current date and time is: " + DateTime.Now);
        }
    }
}
