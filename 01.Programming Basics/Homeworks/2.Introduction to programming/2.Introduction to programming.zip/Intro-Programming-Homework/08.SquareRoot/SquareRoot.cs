﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _08.SquareRoot
{
    class SquareRoot
    {
        static void Main()
        {
            Console.WriteLine("The squre root of 12345 is: " + Math.Sqrt(12345));
        }
    }
}
