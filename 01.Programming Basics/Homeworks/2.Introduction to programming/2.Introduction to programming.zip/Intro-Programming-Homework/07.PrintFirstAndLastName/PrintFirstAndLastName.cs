﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _07.PrintFirstAndLastName
{
    class PrintFirstAndLastName
    {
        static void Main()
        {
            Console.WriteLine("Lyubomir Ivanov");
        }
    }
}
