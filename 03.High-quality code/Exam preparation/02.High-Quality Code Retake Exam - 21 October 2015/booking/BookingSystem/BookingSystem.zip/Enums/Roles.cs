﻿namespace BookingSystem.Enums
{
    public enum Roles
    {
        User,
        VenueAdmin
    }
}
