﻿namespace BoatRacingSimulator.Interfaces
{
    public interface IRunnable
    {
        void Run();
    }
}