﻿namespace BoatRacingSimulator.Interfaces
{
    public interface IWeightable
    {
        int Weight { get; }
    }
}