﻿namespace _06.ExtractHyperlinks
{
    internal class ExtractHyperlinks
    {
        private static void Main()
        {
            
        }
    }
}