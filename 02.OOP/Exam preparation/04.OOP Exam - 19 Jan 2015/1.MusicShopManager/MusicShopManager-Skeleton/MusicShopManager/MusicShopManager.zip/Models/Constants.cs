﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MusicShop.Models
{
    public static class Constants
    {
        public const int BassGuitarNumberOfStrings = 4;
        public const int AcousticAndElectricGuitarsNumberOfStrings = 6;
    }
}
