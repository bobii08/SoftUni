﻿namespace MusicShopManager.Interfaces.Engine
{
    using System;

    public interface IMusicShopEngine
    {
        void Start();
    }
}
