﻿namespace _02.BankOfKurtovoKonare.Models
{
    public enum Customer
    {
        Individual,
        Company
    }
}
