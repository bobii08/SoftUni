﻿namespace Blobs.Models.EventHandlers
{
    using System;

    public delegate void ToggledBehaviorEventHandler(object sender, EventArgs e);
}
