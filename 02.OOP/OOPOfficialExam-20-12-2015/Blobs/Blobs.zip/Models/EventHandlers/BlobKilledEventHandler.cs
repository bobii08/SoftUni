﻿namespace Blobs.Models.EventHandlers
{
    using System;

    public delegate void BlobKilledEventHandler(object sender, EventArgs e);
}
